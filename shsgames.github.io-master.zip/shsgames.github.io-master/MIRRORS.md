# Mirrors
Mirrors are community maintained sites incase all the official sites are blocked for you.

| URL | Status |
| - | - |
| https://artix-hangout.netlify.app | Broken |
| https://bogpog.herokuapp.com | Broken |
| https://breezegames.herokuapp.com | Broken |
| https://cpsgames.herokuapp.com | Outdated |
| http://joe-biden.herokuapp.com | Not Secured |
| https://magixxzshsgames.herokuapp.com | Outdated |
| https://physics-central.com | Outdated |
| https://sh--9pfs.repl.co | ChromeOS Only |
| https://shhstheplayce672.herokuapp.com | Legacy |
| https://shs.barnacled.repl.co | Outdated |
| https://shs.klj2.repl.co | Outdated |
| https://shsgame.herokuapp.com | Broken |
| https://shs-game.herokuapp.com | Outdated |
| http://spotsymath.herokuapp.com | Not Secured |
| https://unbzoked-yay.herokuapp.com | Outdated |
| https://unkxn.netlify.app | Outdated |
| https://virabot-aotic.herokuapp.com | Outdated |