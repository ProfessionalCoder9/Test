import cors from "cors";

// Export middleware
export default cors();
